struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        if question.hasPrefix("Hola") {
            return "Holi :3"
        }
        if question == "¿Como te llamas?"{
            return "Soy Roberto Robot"
        }
        if question.hasSuffix("adios"){
            return "Que tengas un buen dia"
        }
        if question == "Cuentame algo"{
            return "No quiero"
        }
        if question.hasPrefix("¿Quien"){
            return "No sé"
        }
        // PENDIENTE: Escribir una respuesta 
        return "?"
    }
}
